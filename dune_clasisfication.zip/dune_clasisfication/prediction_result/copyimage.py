import pandas as pd
import random
from shutil import copyfile # 提供 copyfile(source, dest) 函数用于文件复制。
# Load the Excel file into a DataFrame
file_path = 'all_id.xlsx'
column_name = 'id'  # Change this to match the column name in your Excel file

# Change the desired number of random IDs you want to select
num_random_ids = 19

# Load the Excel data into a DataFrame
df = pd.read_excel(file_path, usecols=[column_name])

# Convert the DataFrame column to a list
id_list = df[column_name].tolist()

source="D:/Softwares/DuneProject/Data/LandsatCut/random_result_only_different_v2/transverse.png"
for x in id_list:
    print(x)
    dest="D:/Softwares/DuneProject/Data/LandsatCut/random_result_only_different_v2/%d.png"%x
            
    copyfile(source, dest)
